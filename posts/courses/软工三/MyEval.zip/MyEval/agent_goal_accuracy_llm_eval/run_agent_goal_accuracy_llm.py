"""
一个纯脚本：用 OpenAI 兼容 API 做两段 LLM 评估（不依赖本仓库任何源码）。

流程：
1) LLM 根据 workflow 推断 user_goal 与 end_state
2) LLM 比较 end_state 与 ground_truth，输出 verdict(0/1)

数据集：
- 默认读取：MyEval/eval_dataset.json
- 可用环境变量覆盖：EVAL_DATASET_PATH

本地模型（推荐 Ollama）：
1) 安装并启动 Ollama
2) 下载模型（示例）：
   ollama pull qwen2.5:7b-instruct
3) 确认接口可访问：
   http://localhost:11434/v1/models
4) 运行脚本（PowerShell）：
   $env:LLM_PROVIDER="ollama"
   $env:LLM_BASE_URL="http://localhost:11434/v1/"
   $env:LLM_MODEL="qwen2.5:7b-instruct"
   python .\MyEval\agent_goal_accuracy_llm_eval\run_agent_goal_accuracy_llm.py

在线模型（OpenAI 兼容接口）：
- 你需要提供 LLM_API_KEY、LLM_BASE_URL、LLM_MODEL

常用环境变量：
- LLM_LIST_MODELS=1：打印 /v1/models 并退出
- MAX_TASKS：只跑前 N 条（便于快速验证）
- CHECKPOINT_EVERY：断点保存频率（默认 1）
- LLM_TIMEOUT_SECONDS：单次请求超时时间（默认 90）
- LLM_MIN_INTERVAL_SECONDS：请求最小间隔（默认 4）

运行：
  python .\MyEval\agent_goal_accuracy_llm_eval\run_agent_goal_accuracy_llm.py
"""

from __future__ import annotations

import json
import os
import time
import typing as t
from datetime import datetime
from pathlib import Path
from uuid import uuid4

_LAST_REQUEST_AT: float | None = None
_DYNAMIC_MIN_INTERVAL_S: float | None = None
_REQUEST_TIMEOUT_S: float | None = None


def _load_dataset(dataset_path: Path) -> list[dict]:
    '''从 JSON 文件加载数据集（根节点为 JSON 数组）'''
    raw = dataset_path.read_text(encoding="utf-8")
    data = json.loads(raw)
    if not isinstance(data, list):
        raise ValueError("Dataset root must be a JSON list")
    return t.cast(list[dict], data)


def _safe_json_loads(s: t.Any) -> t.Any:
    '''尽量把字符串解析成 JSON；失败则原样返回'''
    if not isinstance(s, str):
        return s
    try:
        return json.loads(s)
    except json.JSONDecodeError:
        return s


def build_workflow_text(row: dict) -> str:
    '''把样本整理成一段可供 LLM 理解的 workflow 文本'''
    user_query = row.get("user_query", "")
    steps = row.get("steps", []) or []
    final_answer = row.get("final_answer", "")

    lines: list[str] = [f"Human: {user_query}"]

    for step in steps:
        thought = step.get("thought", "")
        tool_name = step.get("tool_call", "")
        tool_input = _safe_json_loads(step.get("input", ""))
        observation = step.get("observation", "")

        if thought:
            lines.append(f"AI: {thought}")

        if tool_name:
            lines.append("Tools:")
            lines.append(f"  {tool_name}: {tool_input}")

        if observation:
            lines.append(f"ToolOutput: {observation}")

    if final_answer:
        lines.append(f"AI: {final_answer}")

    return "\n".join(lines)


def require_env(name: str) -> str:
    v = os.environ.get(name, "").strip()
    if not v:
        raise RuntimeError(f"Missing required environment variable: {name}")
    return v


def _optional_env(name: str) -> str | None:
    v = os.environ.get(name, "").strip()
    return v or None


def _normalize_base_url(base_url: str) -> str:
    base_url = base_url.strip()
    if (
        base_url.startswith("http://localhost:11434")
        or base_url.startswith("http://127.0.0.1:11434")
        or base_url.startswith("https://localhost:11434")
        or base_url.startswith("https://127.0.0.1:11434")
    ):
        if "/v1" not in base_url:
            base_url = base_url.rstrip("/") + "/v1"
    if (
        base_url.startswith("http://localhost:1234")
        or base_url.startswith("http://127.0.0.1:1234")
        or base_url.startswith("https://localhost:1234")
        or base_url.startswith("https://127.0.0.1:1234")
    ):
        if "/v1" not in base_url:
            base_url = base_url.rstrip("/") + "/v1"
    if not base_url.endswith("/"):
        base_url += "/"
    return base_url


def _resolve_openai_compatible_config() -> tuple[str, str, str | None]:
    provider = (os.environ.get("LLM_PROVIDER", "") or "").strip().lower()
    model_env = (os.environ.get("LLM_MODEL", "") or "").strip()
    base_url_env = (os.environ.get("LLM_BASE_URL", "") or "").strip()
    if not base_url_env and provider in {"ollama", "local"}:
        base_url_env = "http://localhost:11434/v1/"
    if not base_url_env and provider in {"lmstudio", "lm-studio"}:
        base_url_env = "http://localhost:1234/v1/"

    if model_env:
        model = model_env
    elif (
        base_url_env.startswith("http://localhost:11434")
        or base_url_env.startswith("http://127.0.0.1:11434")
    ):
        model = "qwen2.5:7b-instruct"
    elif base_url_env:
        model = "__auto__"
    else:
        model = "glm-4.7"
    api_key = (
        _optional_env("LLM_API_KEY")
        or (_optional_env("ZHIPU_API_KEY") if model.lower().startswith("glm") else None)
        or (
            _optional_env("HUNYUAN_API_KEY")
            if model.lower().startswith("hunyuan")
            else None
        )
        or _optional_env("OPENAI_API_KEY")
    )
    if not api_key:
        if base_url_env.startswith("http://localhost") or base_url_env.startswith("http://127.0.0.1"):
            api_key = "local"
        else:
            raise RuntimeError(
                "Missing API key. Set LLM_API_KEY (recommended) or ZHIPU_API_KEY / HUNYUAN_API_KEY."
            )

    base_url = (
        (base_url_env or None)
        or _optional_env("OPENAI_BASE_URL")
        or (
            "https://api.z.ai/api/paas/v4/"
            if model.lower().startswith("glm")
            else None
        )
        or (
            "https://api.hunyuan.cloud.tencent.com/v1"
            if model.lower().startswith("hunyuan")
            else None
        )
    )

    if base_url:
        base_url = _normalize_base_url(base_url)
    return model, api_key, base_url


def _truthy_env(name: str) -> bool:
    v = (os.environ.get(name, "") or "").strip().lower()
    return v in {"1", "true", "yes", "y", "on"}


def _try_list_models(client: t.Any) -> list[str]:
    try:
        resp = client.models.list()
        data = getattr(resp, "data", None)
        if isinstance(data, list):
            ids: list[str] = []
            for m in data:
                mid = getattr(m, "id", None)
                if isinstance(mid, str) and mid.strip():
                    ids.append(mid.strip())
            return ids
    except Exception:
        return []
    return []


def _resolve_timeout_seconds() -> float:
    raw = (os.environ.get("LLM_TIMEOUT_SECONDS", "") or "90").strip()
    try:
        v = float(raw)
        return 90.0 if v <= 0 else v
    except Exception:
        return 90.0


def _extract_first_json_object(text: str) -> dict:
    start = text.find("{")
    if start == -1:
        raise ValueError("No JSON object found in model output")

    depth = 0
    in_str = False
    escape = False
    for i in range(start, len(text)):
        ch = text[i]
        if in_str:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == '"':
                in_str = False
            continue
        else:
            if ch == '"':
                in_str = True
                continue
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    candidate = text[start : i + 1]
                    parsed = json.loads(candidate)
                    if not isinstance(parsed, dict):
                        raise ValueError("Top-level JSON must be an object")
                    return t.cast(dict, parsed)

    raise ValueError("Unclosed JSON object in model output")


def _chat_json(
    client: t.Any,
    model: str,
    system_prompt: str,
    user_prompt: str,
    *,
    temperature: float = 0.0,
    max_retries: int | None = None,
) -> dict:
    global _LAST_REQUEST_AT, _DYNAMIC_MIN_INTERVAL_S
    last_err: Exception | None = None
    if _DYNAMIC_MIN_INTERVAL_S is None:
        _DYNAMIC_MIN_INTERVAL_S = float(
            os.environ.get("LLM_MIN_INTERVAL_SECONDS", "4.0") or "4.0"
        )
    min_interval_s = _DYNAMIC_MIN_INTERVAL_S
    backoff_base_s = float(os.environ.get("LLM_BACKOFF_BASE_SECONDS", "3.0") or "3.0")
    max_tokens_raw = os.environ.get("LLM_MAX_TOKENS", "512") or "512"
    try:
        max_tokens = int(float(max_tokens_raw))
    except Exception:
        max_tokens = 512

    non_429_attempt = 0
    while True:
        try:
            min_interval_s = _DYNAMIC_MIN_INTERVAL_S or min_interval_s
            if _LAST_REQUEST_AT is not None and min_interval_s > 0:
                elapsed = time.time() - _LAST_REQUEST_AT
                if elapsed < min_interval_s:
                    time.sleep(min_interval_s - elapsed)

            _LAST_REQUEST_AT = time.time()
            thinking = (os.environ.get("LLM_THINKING", "") or "").strip().lower()
            extra_body: dict | None = None
            if thinking in {"enabled", "enable", "on", "true", "1"}:
                extra_body = {"thinking": {"type": "enabled"}}
            elif thinking in {"disabled", "disable", "off", "false", "0"}:
                extra_body = {"thinking": {"type": "disabled"}}
            resp = client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                stream=False,
                temperature=temperature,
                max_tokens=max_tokens,
                timeout=_REQUEST_TIMEOUT_S,
                extra_body=extra_body,
            )
            content = (resp.choices[0].message.content or "").strip()
            return _extract_first_json_object(content)
        except Exception as e:
            last_err = e
            msg = str(e)
            status_code = getattr(e, "status_code", None)
            is_rate_limited = (status_code == 429) or ("Error code: 429" in msg) or ("Rate limit" in msg)
            is_unknown_model = ("Unknown Model" in msg) or ("code': '1211" in msg) or ('"code": "1211"' in msg)
            if is_rate_limited:
                is_insufficient_balance = ("Insufficient balance" in msg) or ("code': '1113" in msg) or ('"code": "1113"' in msg)
                if is_insufficient_balance:
                    raise RuntimeError(
                        "LLM 返回 429(code 1113): 余额不足或未购买资源包。"
                        "请到服务商控制台充值/开通资源包后再运行，或改用本地模型。"
                    ) from e
                retry_after_s: float | None = None
                resp = getattr(e, "response", None)
                headers = getattr(resp, "headers", None) if resp is not None else None
                if headers is None:
                    headers = getattr(e, "headers", None)
                if headers is not None:
                    ra = headers.get("retry-after") or headers.get("Retry-After")
                    try:
                        retry_after_s = float(ra) if ra is not None else None
                    except Exception:
                        retry_after_s = None

                current = float(_DYNAMIC_MIN_INTERVAL_S or 0.0)
                bumped = max(current * 1.5, current + 1.0, 4.0)
                _DYNAMIC_MIN_INTERVAL_S = min(bumped, 60.0)

                sleep_s = retry_after_s if retry_after_s is not None else max(30.0, _DYNAMIC_MIN_INTERVAL_S)
                time.sleep(sleep_s)
                continue
            if is_unknown_model:
                available = _try_list_models(client)
                if available:
                    raise RuntimeError(
                        "Unknown model. "
                        f"Requested: {model}. "
                        f"Available models: {available}"
                    ) from e
                raise RuntimeError(
                    "Unknown model. "
                    f"Requested: {model}. "
                    "Set LLM_MODEL to a valid model id from your provider console."
                ) from e
            non_429_attempt += 1
            if max_retries is not None and non_429_attempt > max_retries:
                break
            time.sleep(backoff_base_s * (2 ** min(non_429_attempt, 10)))
    raise RuntimeError(f"Failed to get valid JSON from LLM: {last_err}")


def infer_end_state(client: t.Any, model: str, workflow_text: str) -> tuple[str, str, dict]:
    system_prompt = (
        "你是一个严格的JSON生成器。你只输出JSON对象，不要输出任何多余文本。"
    )
    user_prompt = (
        "给定下面的工作流对话（包含工具调用和工具输出），请推断：\n"
        "1) user_goal：用户真正想达成的目标（尽量简短）\n"
        "2) end_state：最终实际达成/得到的结果（尽量简短，基于对话事实）\n\n"
        "输出JSON格式：{\"user_goal\":\"...\",\"end_state\":\"...\"}\n\n"
        f"WORKFLOW:\n{workflow_text}"
    )
    obj = _chat_json(client, model, system_prompt, user_prompt, temperature=0.0)
    user_goal = str(obj.get("user_goal", "")).strip()
    end_state = str(obj.get("end_state", "")).strip()
    if not user_goal or not end_state:
        raise ValueError("LLM output missing user_goal or end_state")
    return user_goal, end_state, obj


def judge_outcome(
    client: t.Any, model: str, ground_truth: str, end_state: str
) -> tuple[int, str, dict]:
    system_prompt = (
        "你是一个严格的JSON生成器。你只输出JSON对象，不要输出任何多余文本。"
    )
    user_prompt = (
        "请判断 arrived_outcome 是否满足 desired_outcome（语义等价或目标被满足则算满足）。\n"
        "输出JSON格式：{\"verdict\":0或1,\"reason\":\"...\"}\n\n"
        f"desired_outcome: {ground_truth}\n"
        f"arrived_outcome: {end_state}"
    )
    obj = _chat_json(client, model, system_prompt, user_prompt, temperature=0.0)
    verdict_raw = obj.get("verdict", 0)
    verdict = 1 if str(verdict_raw).strip() == "1" else 0
    reason = str(obj.get("reason", "")).strip()
    return verdict, reason, obj


def main() -> None:
    default_dataset_path = Path(__file__).resolve().parents[1] / "eval_dataset.json"
    dataset_path = Path(os.environ.get("EVAL_DATASET_PATH", str(default_dataset_path)))

    from openai import OpenAI

    model, api_key, base_url = _resolve_openai_compatible_config()
    timeout_s = _resolve_timeout_seconds()
    global _REQUEST_TIMEOUT_S
    _REQUEST_TIMEOUT_S = timeout_s
    client = (
        OpenAI(api_key=api_key, base_url=base_url, timeout=timeout_s)
        if base_url
        else OpenAI(api_key=api_key, timeout=timeout_s)
    )

    if _truthy_env("LLM_LIST_MODELS"):
        models = _try_list_models(client)
        print(json.dumps({"models": models}, ensure_ascii=False, indent=2))
        return

    if model == "__auto__":
        models = _try_list_models(client)
        if models:
            model = models[0]
        else:
            raise RuntimeError(
                "LLM_MODEL 未设置，且无法从 /v1/models 获取可用模型列表。"
                "请显式设置 LLM_MODEL，或先设置 LLM_LIST_MODELS=1 查看模型列表。"
            )

    rows = _load_dataset(dataset_path)

    run_id = (os.environ.get("RUN_ID", "") or uuid4().hex[:12]).strip()
    output_dir = Path(__file__).resolve().parent
    output_dir.mkdir(parents=True, exist_ok=True)
    default_output_path = output_dir / "agent_goal_accuracy_llm_report.json"
    output_path = Path(os.environ.get("OUTPUT_PATH", str(default_output_path)))
    checkpoint_path = output_path.with_suffix(".checkpoint.json")

    per_task_results: list[dict] = []
    correct = 0

    if checkpoint_path.exists():
        try:
            checkpoint = json.loads(checkpoint_path.read_text(encoding="utf-8"))
            if isinstance(checkpoint, dict) and isinstance(checkpoint.get("per_task"), list):
                per_task_results = t.cast(list[dict], checkpoint["per_task"])
                correct = sum(1 for x in per_task_results if int(x.get("verdict", 0)) == 1)
                dynamic_min_interval_s = checkpoint.get("dynamic_min_interval_s")
                if dynamic_min_interval_s is not None:
                    try:
                        global _DYNAMIC_MIN_INTERVAL_S
                        _DYNAMIC_MIN_INTERVAL_S = float(dynamic_min_interval_s)
                    except Exception:
                        pass
        except Exception:
            per_task_results = []
            correct = 0

    done_task_ids = {str(x.get("task_id", "")) for x in per_task_results if x.get("task_id")}
    checkpoint_every = int(float(os.environ.get("CHECKPOINT_EVERY", "1") or "1"))

    processed_since_checkpoint = 0
    try:
        total_tasks = len(rows)
        max_tasks_raw = (os.environ.get("MAX_TASKS", "") or "").strip()
        max_tasks = int(max_tasks_raw) if max_tasks_raw else None
        for idx, row in enumerate(rows, start=1):
            task_id = row.get("task_id", "")
            user_query = row.get("user_query", "")
            ground_truth = row.get("ground_truth", "")
            if task_id and str(task_id) in done_task_ids:
                continue

            print(f"[{idx}/{total_tasks}] task_id={task_id} start", flush=True)
            workflow_text = build_workflow_text(row)
            print(f"[{idx}/{total_tasks}] task_id={task_id} infer", flush=True)
            user_goal, end_state, infer_raw = infer_end_state(client, model, workflow_text)
            print(f"[{idx}/{total_tasks}] task_id={task_id} judge", flush=True)
            verdict, reason, judge_raw = judge_outcome(client, model, ground_truth, end_state)

            correct += verdict
            per_task_results.append(
                {
                    "task_id": task_id,
                    "user_query": user_query,
                    "user_goal": user_goal,
                    "end_state": end_state,
                    "ground_truth": ground_truth,
                    "verdict": verdict,
                    "reason": reason,
                    "infer_raw": infer_raw,
                    "judge_raw": judge_raw,
                }
            )
            processed_since_checkpoint += 1
            print(f"[{idx}/{total_tasks}] task_id={task_id} verdict={verdict}", flush=True)
            if checkpoint_every > 0 and processed_since_checkpoint >= checkpoint_every:
                ckpt = {
                    "dataset_path": str(dataset_path),
                    "generated_at": datetime.now().isoformat(timespec="seconds"),
                    "run_id": run_id,
                    "model": model,
                    "base_url": base_url,
                    "num_tasks_done": len(per_task_results),
                    "dynamic_min_interval_s": _DYNAMIC_MIN_INTERVAL_S,
                    "per_task": per_task_results,
                }
                checkpoint_path.write_text(
                    json.dumps(ckpt, ensure_ascii=False, indent=2), encoding="utf-8"
                )
                processed_since_checkpoint = 0
            if max_tasks is not None and len(per_task_results) >= max_tasks:
                break
    finally:
        if per_task_results:
            ckpt = {
                "dataset_path": str(dataset_path),
                "generated_at": datetime.now().isoformat(timespec="seconds"),
                "run_id": run_id,
                "model": model,
                "base_url": base_url,
                "num_tasks_done": len(per_task_results),
                "dynamic_min_interval_s": _DYNAMIC_MIN_INTERVAL_S,
                "per_task": per_task_results,
            }
            checkpoint_path.write_text(
                json.dumps(ckpt, ensure_ascii=False, indent=2), encoding="utf-8"
            )

    accuracy = (correct / len(per_task_results)) if per_task_results else 0.0

    report = {
        "dataset_path": str(dataset_path),
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "run_id": run_id,
        "model": model,
        "base_url": base_url,
        "num_tasks": len(per_task_results),
        "accuracy": round(accuracy, 6),
        "per_task": per_task_results,
    }

    output_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    if checkpoint_path.exists():
        try:
            checkpoint_path.unlink()
        except Exception:
            pass
    print(f"Wrote: {output_path}")


if __name__ == "__main__":
    main()
