import json
import math
import os
import typing as t
from datetime import datetime
from pathlib import Path
from pprint import pformat
from uuid import uuid4


def make_hashable(obj: t.Any) -> t.Any:
    '''将任意对象转换为可哈希的类型，递归处理嵌套结构'''
    if isinstance(obj, dict):
        return frozenset((k, make_hashable(v)) for k, v in obj.items())
    if isinstance(obj, (list, tuple)):
        return tuple(make_hashable(item) for item in obj)
    if isinstance(obj, set):
        return frozenset(make_hashable(item) for item in obj)
    return obj


def to_tool_call_key(tool_name: str, tool_args: dict) -> t.Tuple[str, t.Any]:
    return (tool_name, make_hashable(tool_args))


def tp(actual: t.Set[t.Any], expected: t.Set[t.Any]) -> int:
    return len(actual & expected)


def fp(actual: t.Set[t.Any], expected: t.Set[t.Any]) -> int:
    return len(actual - expected)


def fn(actual: t.Set[t.Any], expected: t.Set[t.Any]) -> int:
    return len(expected - actual)


def precision(tp_count: int, fp_count: int) -> float:
    '''P'''
    denom = tp_count + fp_count
    return tp_count / denom if denom > 0 else 0.0


def recall(tp_count: int, fn_count: int) -> float:
    '''R'''
    denom = tp_count + fn_count
    return tp_count / denom if denom > 0 else 0.0


def f1(p: float, r: float) -> float:
    denom = p + r
    return (2 * p * r / denom) if denom > 0 else 0.0


def parse_tool_calls_from_steps(steps: t.Sequence[dict]) -> t.Set[t.Tuple[str, t.Any]]:
    '''从步骤序列中解析出所有工具调用'''
    calls: t.Set[t.Tuple[str, t.Any]] = set()
    for step in steps:
        tool_name = step.get("tool_call")
        input_str = step.get("input", "")
        if not tool_name or not isinstance(tool_name, str):
            continue
        try:
            tool_args = json.loads(input_str) if isinstance(input_str, str) else {}
        except json.JSONDecodeError:
            tool_args = {"__raw_input__": input_str}
        if not isinstance(tool_args, dict):
            tool_args = {"__parsed_input__": tool_args}
        calls.add(to_tool_call_key(tool_name, tool_args))
    return calls


def safe_float(v: t.Any) -> float:
    '''将任意值转换为浮点数，处理NaN、Inf等异常情况'''
    try:
        x = float(v)
        if math.isnan(x) or math.isinf(x):
            return 0.0
        return x
    except Exception:
        return 0.0


def main():
    default_dataset_path = Path(__file__).resolve().parents[1] / "eval_dataset.json"
    dataset_path = Path(os.environ.get("EVAL_DATASET_PATH", str(default_dataset_path)))
    output_dir = Path(__file__).resolve().parent
    output_dir.mkdir(parents=True, exist_ok=True)

    run_id = uuid4().hex[:12]
    output_path = output_dir / f"tool_call_f1_report_{run_id}.txt"

    rows = json.loads(dataset_path.read_text(encoding="utf-8"))
    if not isinstance(rows, list):
        raise ValueError("Dataset root must be a JSON list")

    per_task = []
    sum_tp = 0
    sum_fp = 0
    sum_fn = 0
    f1_values: t.List[float] = []

    for row in rows:
        task_id = row.get("task_id", "")
        user_query = row.get("user_query", "")
        steps = row.get("steps", []) or []
        expected_steps = row.get("expected_steps", []) or []

        actual = parse_tool_calls_from_steps(steps)
        expected = parse_tool_calls_from_steps(expected_steps)

        tp_count = tp(actual, expected)
        fp_count = fp(actual, expected)
        fn_count = fn(actual, expected)
        p = precision(tp_count, fp_count)
        r = recall(tp_count, fn_count)
        score = f1(p, r)

        sum_tp += tp_count
        sum_fp += fp_count
        sum_fn += fn_count
        f1_values.append(score)

        per_task.append(
            {
                "task_id": task_id,
                "user_query": user_query,
                "tp": tp_count,
                "fp": fp_count,
                "fn": fn_count,
                "precision": round(p, 6),
                "recall": round(r, 6),
                "f1": round(score, 6),
                "actual_tool_calls_count": len(actual),
                "expected_tool_calls_count": len(expected),
            }
        )

    micro_p = precision(sum_tp, sum_fp)
    micro_r = recall(sum_tp, sum_fn)
    micro_f1 = f1(micro_p, micro_r)

    macro_f1 = (
        sum(f1_values) / len(f1_values) if len(f1_values) > 0 else float("nan")
    )

    report = {
        "dataset_path": str(dataset_path),
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "run_id": run_id,
        "num_tasks": len(per_task),
        "micro": {
            "tp": sum_tp,
            "fp": sum_fp,
            "fn": sum_fn,
            "precision": round(micro_p, 6),
            "recall": round(micro_r, 6),
            "f1": round(micro_f1, 6),
        },
        "macro": {"f1": round(safe_float(macro_f1), 6)},
        "per_task": per_task,
    }

    output_path.write_text(pformat(report, width=120), encoding="utf-8")
    print(f"Wrote: {output_path}")


if __name__ == "__main__":
    main()

