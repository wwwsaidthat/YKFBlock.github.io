# 标准选择原因

1. Tool Call F1
   1. **数据和指标的高度契合**：本数据集同时提供了 `steps/tool_call/input` 与 `expected_steps` 两类信息，能够自然构造“模型实际工具调用集合”与“参考工具调用集合”的对照关系。因此，Tool Call F1 在数据结构层面与任务标注高度契合，计算过程清晰且可复现。
   2. **刻画更加全面和稳健**：相较于仅使用单一准确率指标，F1 更能稳健刻画工具调用质量。工具使用场景中常见“遗漏调用”（FN）与“冗余调用”（FP）两类误差，F1 同时综合精确率与召回率，能够更全面地反映代理在工具规划与选择上的真实表现。
2. Agent Goal Accuracy
   1. **数据和指标的高度契合**：Agent Goal Accuracy 直接衡量“任务目标是否被达成”。数据集中包含 `ground_truth`（期望达成的目标/结果）以及完整执行轨迹（`steps + observation + final_answer`），适合将每个样本归约为“成功/失败”的二分类（0/1）判定，从结果层面评价代理的有效性。
   2. **该指标与 Tool Call F1 形成互补**：Tool Call F1 关注过程层面的“工具调用是否与参考一致”，但工具调用一致并不必然意味着任务成功，反之亦然。Agent Goal Accuracy 从最终结果层面评估成功率，与 Tool Call F1 共同覆盖“过程正确性”与“结果正确性”，从而提供更完整、立体的代理能力评估框架。




# 指标实现过程

本项目的两个指标分别对应两段独立脚本，均以 `MyEval/eval_dataset.json` 为输入，输出可复现的 JSON 报告文件。

## 1. Tool Call F1（过程层面）

对应脚本：`MyEval/toolcall_f1_eval/run_toolcall_f1.py`

实现流程：
1. **读取数据集**：加载 `eval_dataset.json`（根节点为列表），逐条处理样本。
2. **构造工具调用集合**：
   - **预测集合**：从样本的 `steps` 中抽取每一步的 `tool_call` 与 `input`，将其作为一次工具调用的“标识”。
   - **参考集合**：从样本的 `expected_steps` 中抽取对应的工具调用信息，形成参考调用集合。
3. **规范化与可比较化**：
   - 将 `input` 进行 JSON 解析或保持原样，以降低“字符串格式差异”对比对结果的干扰。
   - 将工具调用对象转换为可 hash 的结构（如元组/冻结结构），以便进行集合运算（交集/差集）。
4. **计算 TP/FP/FN**：
   - TP：预测集合 ∩ 参考集合
   - FP：预测集合 − 参考集合
   - FN：参考集合 − 预测集合
5. **计算 Precision / Recall / F1**：
   - Precision = TP / (TP + FP)
   - Recall = TP / (TP + FN)
   - F1 = 2PR / (P + R)
6. **输出结果**：生成包含整体统计与逐样本统计的报告文件，写入脚本目录下的输出文件夹，便于后续分析与复查。

## 2. Agent Goal Accuracy（结果层面）

对应脚本：`MyEval/agent_goal_accuracy_llm_eval/run_agent_goal_accuracy_llm.py`

实现流程（两段 LLM 判定）：
1. **读取数据集**：加载 `eval_dataset.json`，逐条处理样本。
2. **构建可判定的 workflow 文本**：
   - 将 `user_query`、每一步 `steps`（包含 `thought/tool_call/input/observation`）、以及 `final_answer` 拼接为一段“工作流对话文本”，作为 LLM 的输入依据。
3. **第一段：推断 end_state**（归约执行结果）：
   - 让 LLM 从 workflow 中抽取：
     - `user_goal`：用户真正想达成的目标
     - `end_state`：最终实际达成/得到的结果（基于对话事实）
   - 强制 LLM 输出 JSON：`{"user_goal":"...","end_state":"..."}`
4. **第二段：与 ground_truth 对齐判定**（二分类 0/1）：
   - 将 `end_state` 与样本 `ground_truth` 输入给 LLM，判断是否“语义等价/目标被满足”，输出：
     - `verdict`：0 或 1
     - `reason`：判定理由
   - 最终每条样本的 Agent Goal Accuracy 记为 `verdict`。
5. **汇总与报告**：
   - overall accuracy = 所有样本 verdict 的平均值
   - 输出 `agent_goal_accuracy_llm_report.json`，包含 `accuracy` 以及 `per_task` 的推断与判定明细，支持复核。
6. **可运行性与鲁棒性设计**：
   - 支持断点续跑（checkpoint），避免中断后重复计费/重复推理。
   - 针对不同 OpenAI 兼容服务，提供统一配置入口（本地 Ollama/LM Studio 或在线服务）。

### 运行配置（示例）

- 本地 Ollama：
  - `LLM_BASE_URL=http://localhost:11434/v1/`
  - `LLM_MODEL=qwen2.5:7b-instruct`
  - `LLM_API_KEY=local`（本地一般不校验，可随意）
- 在线 OpenAI 兼容服务：
  - 需要正确设置 `LLM_BASE_URL`、`LLM_MODEL`、`LLM_API_KEY`

# 评估结果分析  
